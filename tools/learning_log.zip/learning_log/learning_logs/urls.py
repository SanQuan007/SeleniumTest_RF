"""
定义learning_logs的URL模式
"""
from django.urls import path, re_path
from . import views

urlpatterns = [
    #主页
    re_path(r'^$', views.index, name='index'),
    re_path(r'^topics/$', views.topics, name='topics'),
    re_path(r'^topics/(?P<topic_id>\d+)$', views.topic, name='topic'),
    re_path(r'^new_topic$', views.new_topic, name='new_topic'),
    # 用于删除主题的页面
    re_path(r'^delete_topic/(?P<topic_id>\d+)$$', views.delete_topic, name='delete_topic'),
    #用于添加新条目的页面
    re_path(r'^new_entry/(?P<topic_id>\d+)$', views.new_entry, name='new_entry'),
    #用于编辑条目的页面
    re_path(r'^edit_entry/(?P<entry_id>\d+)$', views.edit_entry, name='edit_entry'),
    # 用于删除条目的页面
    re_path(r'^delete_entry/(?P<entry_id>\d+)$', views.delete_entry, name='delete_entry'),

]
